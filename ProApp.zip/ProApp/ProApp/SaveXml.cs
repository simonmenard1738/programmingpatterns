﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ProApp
{
    internal abstract class SaveXml
    {
        static BinaryFormatter sr = new BinaryFormatter();
        static int objCount = 0;
        static DirectoryInfo target = new DirectoryInfo(Directory.GetCurrentDirectory()+"\\save");
        public static void SaveData(object obj, string fileName)
        {
            FileStream overwrite = new FileStream(fileName, FileMode.Create);
            sr.Serialize(overwrite, obj);
            overwrite.Close();
        }

        public static void SaveAll() {
            foreach (Book book in Library.Books.Values) {
                objCount++;
                SaveData(book, $"{target.FullName}\\book{objCount}");
            }
        }

        public static void LoadAll() {
            foreach (var file in target.GetFiles()) {
                FileStream load = new FileStream(file.FullName, FileMode.Open);
                Book newBook = sr.Deserialize(load) as Book;
                //MessageBox.Show(newBook.ToString());
                Library.AddBook(newBook);
                load.Close();
            }
            
        }
    }
}
