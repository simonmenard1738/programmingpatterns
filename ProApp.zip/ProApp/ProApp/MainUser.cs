﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProApp
{
    public partial class MainUser : Form
    {
        
        public MainUser()
        {
            InitializeComponent();
            //this.TestCase();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Form1 Form1 = new Form1();
            this.Hide();
            Form1.Show();

        }

        private void label5_Click(object sender, EventArgs e)
        {
            Register Register = new Register();
            this.Hide();
            Register.Show();
        }

        
        public void TestCase()
        {

            Library.AddBook(new Book("Harry Potter", "12", "Fantasy", "John", "Publisher"));
            Library.AddBook(new Book("John Smith", "54", "Action", "Jimmy", "Publisher"));
            Library.AddBook(new Book("Harry Potter 2", "22", "Fantasy", "John", "Publisher"));
        }
        


        private void searchButton_Click(object sender, EventArgs e)
        {

            if (bookNameTextBox.Text.Length != 0)
            {
                resultsOutput.Text = "";
                var results = Library.SearchBook(bookNameTextBox.Text);
                if (results!=null)
                {
                    resultsOutput.Text += $"{"BOOK ID",-15} {"TITLE",15} {"GENRE",15} {"AUTHOR",15}  {Environment.NewLine}";
                    foreach (var book in results)
                    {
                        resultsOutput.Text += $"{book.BookId,-15} {book.Title,15} {book.Genre,15} {book.Author,15}  {Environment.NewLine}";
                    }
                }
            }
        }
    }
}
