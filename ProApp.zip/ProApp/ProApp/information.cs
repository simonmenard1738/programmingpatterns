﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProApp
{
    public class information
    {
            private string txtData1;
            private string txtData2;
            private string txtDataw;
    }
}
