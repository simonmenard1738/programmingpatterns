﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Reflection.Metadata.BlobBuilder;

namespace ProApp
{
    public abstract class Library
    {
        private static Hashtable books = new Hashtable();

        public static Hashtable Books { get { return books; } }
            
        public static void AddBook(Book book)
        {
            books.Add(book.Title, book);
        }

        public static Book GetBook(string bookId)
        {
            if (books.ContainsKey(bookId))
            {
                return (Book)books[bookId];
            }
            else
            {
                return null;
            }
        }

        public static void RemoveBook(string bookId)
        {
            books.Remove(bookId);
        }

        public static List<Book> SearchBook(string bookTitle)
        {

            Regex alike = new Regex($"{bookTitle}");
            List<Book> selectedBooks = new List<Book>();

            var selects =
                from book in books.Keys.Cast<string>().ToList()
                where alike.IsMatch(book)
                select book;

            foreach (var select in selects)
            {
                selectedBooks.Add(books[select] as Book);
            }

            if (selectedBooks.Count == 0)
            {
                return null;
            }
            else {
                return selectedBooks;
            }
        }


    }

}