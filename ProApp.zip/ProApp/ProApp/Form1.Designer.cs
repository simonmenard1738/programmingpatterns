﻿namespace ProApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.userBox = new System.Windows.Forms.TextBox();
            this.pssBox = new System.Windows.Forms.TextBox();
            this.ClearFiledLabel = new System.Windows.Forms.Label();
            this.hideButton = new System.Windows.Forms.Button();
            this.viewButton = new System.Windows.Forms.Button();
            this.LogoLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(122, 356);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 39);
            this.button1.TabIndex = 0;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(165, 407);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Exit";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // userBox
            // 
            this.userBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.userBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.userBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.userBox.Location = new System.Drawing.Point(54, 207);
            this.userBox.Name = "userBox";
            this.userBox.Size = new System.Drawing.Size(238, 22);
            this.userBox.TabIndex = 2;
            // 
            // pssBox
            // 
            this.pssBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pssBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pssBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pssBox.Location = new System.Drawing.Point(54, 252);
            this.pssBox.Name = "pssBox";
            this.pssBox.PasswordChar = '*';
            this.pssBox.Size = new System.Drawing.Size(238, 22);
            this.pssBox.TabIndex = 3;
            // 
            // ClearFiledLabel
            // 
            this.ClearFiledLabel.AutoSize = true;
            this.ClearFiledLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ClearFiledLabel.ForeColor = System.Drawing.Color.Black;
            this.ClearFiledLabel.Location = new System.Drawing.Point(199, 288);
            this.ClearFiledLabel.Name = "ClearFiledLabel";
            this.ClearFiledLabel.Size = new System.Drawing.Size(93, 21);
            this.ClearFiledLabel.TabIndex = 4;
            this.ClearFiledLabel.Text = "Clear Fields";
            this.ClearFiledLabel.Click += new System.EventHandler(this.ClearFiledLabel_Click_1);
            // 
            // hideButton
            // 
            this.hideButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.hideButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hideButton.BackgroundImage")));
            this.hideButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.hideButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hideButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.hideButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.hideButton.Location = new System.Drawing.Point(298, 252);
            this.hideButton.Name = "hideButton";
            this.hideButton.Size = new System.Drawing.Size(26, 22);
            this.hideButton.TabIndex = 5;
            this.hideButton.UseVisualStyleBackColor = false;
            this.hideButton.Click += new System.EventHandler(this.hideButton_Click);
            // 
            // viewButton
            // 
            this.viewButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.viewButton.BackgroundImage = global::ProApp.Properties.Resources.eyeIcon;
            this.viewButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.viewButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viewButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.viewButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.viewButton.Location = new System.Drawing.Point(298, 252);
            this.viewButton.Name = "viewButton";
            this.viewButton.Size = new System.Drawing.Size(26, 22);
            this.viewButton.TabIndex = 6;
            this.viewButton.UseVisualStyleBackColor = false;
            this.viewButton.Click += new System.EventHandler(this.viewButton_Click_2);
            // 
            // LogoLabel
            // 
            this.LogoLabel.Image = ((System.Drawing.Image)(resources.GetObject("LogoLabel.Image")));
            this.LogoLabel.Location = new System.Drawing.Point(134, 23);
            this.LogoLabel.Name = "LogoLabel";
            this.LogoLabel.Size = new System.Drawing.Size(100, 100);
            this.LogoLabel.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(18, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 22);
            this.label3.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(18, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 22);
            this.label4.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LogoLabel);
            this.Controls.Add(this.viewButton);
            this.Controls.Add(this.hideButton);
            this.Controls.Add(this.ClearFiledLabel);
            this.Controls.Add(this.pssBox);
            this.Controls.Add(this.userBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login Page";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button1;
        private Label label1;
        private TextBox userBox;
        private TextBox pssBox;
        private Label ClearFiledLabel;
        private Button hideButton;
        private Button viewButton;
        private Label LogoLabel;
        private Label label3;
        private Label label4;
    }
}